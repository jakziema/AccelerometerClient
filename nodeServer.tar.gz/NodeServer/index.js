var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.get('/', function(req, res){
  res.send('<h1>Iphone server for accelerometer data</h1>');
});

http.listen(3000,function(){
   console.log('listening on *:3000');
});

io.on('connection', function(clientSocket){
   console.log('a user connected');

   clientSocket.on('disconnect', function(){
      console.log('a user disconnected');
   });

   clientSocket.on('message', function(message){
      console.log("Message from client: " + message)
   });
});
